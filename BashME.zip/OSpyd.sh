pip install --upgrade pip
pip install spyder
spyder
