install-pkg firefox
firefox